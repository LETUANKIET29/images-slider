"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight, Pause, Play, X } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

// Main background slides
const backgroundSlides = [
  {
    id: 1,
    src: "https://wallpapercave.com/wp/wp2506793.jpg",
    title: "FINLA",
    description: "Khám phá vẻ đẹp của thung lũng núi và hoàng hôn tuyệt đẹp",
    expandedContent: {
      title: "Khám phá vùng núi FINLA",
      description:
        "Vùng núi FINLA nổi tiếng với những cánh rừng thông xanh ngát, thung lũng trải dài và không khí trong lành. Đây là điểm đến lý tưởng cho những người yêu thích thiên nhiên và các hoạt động ngoài trời như đi bộ đường dài, cắm trại và leo núi.",
      features: [
        "Đỉnh núi cao nhất đạt 3,200m",
        "Hơn 200 loài thực vật quý hiếm",
        "Hệ sinh thái đa dạng với nhiều loài động vật hoang dã",
        "Nhiều đường mòn đi bộ đường dài với các cấp độ khó khác nhau",
      ],
      imageGallery: [
        "https://wallpapercave.com/wp/wp2506793.jpg",
        "https://wallpapercave.com/wp/wp2506795.jpg",
        "https://wallpapercave.com/wp/wp2506811.jpg",
      ],
    },
  },
  {
    id: 2,
    src: "https://wallpapercave.com/wp/wp2506795.jpg",
    title: "TERRA",
    description: "Bãi biển ẩn giấu với thác nước và vách đá ngoạn mục",
    expandedContent: {
      title: "Khám phá bờ biển TERRA",
      description:
        "Bờ biển TERRA là một trong những kỳ quan thiên nhiên với những vách đá hùng vĩ, thác nước đổ thẳng xuống bãi biển và làn nước màu ngọc lam tuyệt đẹp. Vùng đất này mang vẻ đẹp hoang sơ, kỳ bí và đầy mê hoặc.",
      features: [
        "Thác nước độc đáo đổ trực tiếp xuống bãi biển",
        "Vách đá cao tới 80m bao quanh bãi biển",
        "Nước biển trong xanh với màu ngọc lam đặc trưng",
        "Hoàng hôn tuyệt đẹp với ánh sáng vàng cam phản chiếu trên vách đá",
      ],
      imageGallery: [
        "https://wallpapercave.com/wp/wp2506795.jpg",
        "https://wallpapercave.com/wp/wp2506811.jpg",
        "https://wallpapercave.com/wp/wp2506793.jpg",
      ],
    },
  },
  {
    id: 3,
    src: "https://wallpapercave.com/wp/wp2506811.jpg",
    title: "AQUA",
    description: "Thiên đường biển xanh với bãi cát trắng mịn và nước trong vắt",
    expandedContent: {
      title: "Khám phá thiên đường biển AQUA",
      description:
        "AQUA là thiên đường nhiệt đới với những bãi biển cát trắng mịn, nước biển trong xanh như ngọc và hệ sinh thái biển phong phú. Đây là điểm đến hoàn hảo cho những ai yêu thích biển và các hoạt động dưới nước.",
      features: [
        "Hơn 50 bãi biển hoang sơ",
        "Rạn san hô đa dạng với hơn 500 loài cá nhiệt đới",
        "Nhiều hoạt động như lặn biển, lướt sóng và chèo thuyền kayak",
        "Những khu rừng nhiệt đới ven biển với thác nước tuyệt đẹp",
      ],
      imageGallery: [
        "https://wallpapercave.com/wp/wp2506811.jpg",
        "https://wallpapercave.com/wp/wp2506793.jpg",
        "https://wallpapercave.com/wp/wp2506795.jpg",
      ],
    },
  },
]

export function NatureSlider() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)
  const [direction, setDirection] = useState("next") // "next" or "prev"
  const [isAnimating, setIsAnimating] = useState(false)
  const [showExpanded, setShowExpanded] = useState(false)
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  const goToSlide = useCallback(
    (index: number, dir: "next" | "prev") => {
      if (isAnimating) return

      setIsAnimating(true)
      setDirection(dir)
      setCurrentIndex(index)

      // Reset animation state after animation completes
      setTimeout(() => {
        setIsAnimating(false)
      }, 800)
    },
    [isAnimating],
  )

  const nextSlide = useCallback(() => {
    const newIndex = (currentIndex + 1) % backgroundSlides.length
    goToSlide(newIndex, "next")
  }, [currentIndex, goToSlide])

  const prevSlide = useCallback(() => {
    const newIndex = (currentIndex - 1 + backgroundSlides.length) % backgroundSlides.length
    goToSlide(newIndex, "prev")
  }, [currentIndex, goToSlide])

  const toggleAutoPlay = useCallback(() => {
    setIsAutoPlaying((prev) => !prev)
  }, [])

  const handleSeeMoreClick = useCallback(() => {
    setIsAutoPlaying(false) // Pause autoplay when expanded view is shown
    setShowExpanded(true)
  }, [])

  const handleCloseExpanded = useCallback(() => {
    setShowExpanded(false)
    // Optional: resume autoplay when closed
    // setIsAutoPlaying(true)
  }, [])

  useEffect(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current)
      timerRef.current = null
    }

    if (isAutoPlaying && !isAnimating && !showExpanded) {
      timerRef.current = setInterval(() => {
        nextSlide()
      }, 6000)
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [isAutoPlaying, nextSlide, isAnimating, showExpanded])

  // Calculate previous and next indices for animation
  const prevIndex = (currentIndex - 1 + backgroundSlides.length) % backgroundSlides.length
  const nextIndex = (currentIndex + 1) % backgroundSlides.length

  // Get current slide data
  const currentSlide = backgroundSlides[currentIndex]

  // Get the other two images for the cards (different from current background)
  const getCardImages = (currentImageSrc: string) => {
    const otherImages = backgroundSlides.map((slide) => slide.src).filter((src) => src !== currentImageSrc)

    // Return the two other images plus the current one in the middle
    return [otherImages[0], currentImageSrc, otherImages[1]]
  }

  return (
    <div className="relative w-full h-[600px] md:h-[700px] lg:h-[800px] overflow-hidden">
      {/* Background slides with animation */}
      <div className="relative w-full h-full">
        {backgroundSlides.map((slide, index) => (
          <div
            key={slide.id}
            className={cn(
              "absolute inset-0 w-full h-full transition-transform duration-800 ease-in-out",
              index === currentIndex && "z-10",
              index === prevIndex && "z-0",
              index === nextIndex && "z-0",
              index === currentIndex && direction === "next" && !isAnimating && "translate-x-0",
              index === currentIndex && direction === "prev" && !isAnimating && "translate-x-0",
              index === currentIndex && direction === "next" && isAnimating && "animate-slide-in-right",
              index === currentIndex && direction === "prev" && isAnimating && "animate-slide-in-left",
              index !== currentIndex && index !== prevIndex && index !== nextIndex && "-z-10 opacity-0",
              index === prevIndex && direction === "next" && isAnimating && "animate-slide-out-left",
              index === nextIndex && direction === "prev" && isAnimating && "animate-slide-out-right",
            )}
            style={{
              opacity:
                index === currentIndex ? 1 : index === prevIndex || index === nextIndex ? (isAnimating ? 1 : 0) : 0,
            }}
          >
            <Image
              src={slide.src || "/placeholder.svg"}
              alt={slide.title}
              fill
              priority={index === 0}
              className="object-cover"
            />

            {/* Text overlay with animation */}
            <div
              className={cn(
                "absolute top-1/4 left-[10%] max-w-md text-white z-20 transition-all duration-500",
                isAnimating ? "opacity-0 translate-y-10" : "opacity-100 translate-y-0",
              )}
              style={{
                transitionDelay: isAnimating ? "0ms" : "300ms",
              }}
            >
              <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-4">{slide.title}</h2>
              <p className="text-lg md:text-xl mb-6">{slide.description}</p>
              <Button
                variant="outline"
                className="bg-white/10 backdrop-blur-sm border-white text-white hover:bg-white/30 hover:scale-105 active:scale-95 transition-all duration-300"
                onClick={handleSeeMoreClick}
              >
                See more
              </Button>
            </div>

            {/* Overlapping cards with animation */}
            <div className="absolute bottom-[15%] right-[10%] flex items-center z-10">
              {getCardImages(slide.src).map((imageSrc, cardIndex) => (
                <div
                  key={cardIndex}
                  className={cn(
                    "relative rounded-3xl overflow-hidden shadow-2xl cursor-pointer transition-all duration-700",
                    cardIndex === 0 && "h-[280px] w-[180px] md:h-[350px] md:w-[220px] z-10 -mr-6 md:-mr-10",
                    cardIndex === 1 && "h-[320px] w-[200px] md:h-[400px] md:w-[250px] z-20 -mr-6 md:-mr-10",
                    cardIndex === 2 && "h-[280px] w-[180px] md:h-[350px] md:w-[220px] z-10",
                    isAnimating && "opacity-0 translate-y-20",
                  )}
                  style={{
                    transform: `translateY(${cardIndex === 1 ? "-30px" : "0"}) ${isAnimating ? "translateY(20px)" : ""}`,
                    transitionDelay: isAnimating ? "0ms" : `${cardIndex * 200 + 400}ms`,
                    opacity: isAnimating ? 0 : 1,
                  }}
                  onClick={() => {
                    // When clicking a card, go to the next slide or previous slide
                    if (cardIndex === 0) prevSlide()
                    else if (cardIndex === 2) nextSlide()
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = `translateY(${cardIndex === 1 ? "-40px" : "-10px"}) scale(1.05)`
                    e.currentTarget.style.boxShadow = "0 25px 50px -12px rgba(0, 0, 0, 0.5)"
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = `translateY(${cardIndex === 1 ? "-30px" : "0"})`
                    e.currentTarget.style.boxShadow = ""
                  }}
                >
                  <Image
                    src={imageSrc || "/placeholder.svg"}
                    alt={`Nature image ${cardIndex + 1}`}
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-black/0 hover:bg-black/20 transition-colors duration-300"></div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Navigation buttons */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex space-x-4 z-30">
        <Button
          variant="outline"
          size="icon"
          className="bg-white/10 backdrop-blur-sm border-white text-white hover:bg-white/20 h-12 w-12 rounded-full"
          onClick={prevSlide}
          aria-label="Previous slide"
          disabled={isAnimating}
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>

        <Button
          variant="outline"
          size="icon"
          className="bg-white/10 backdrop-blur-sm border-white text-white hover:bg-white/20 h-12 w-12 rounded-full"
          onClick={toggleAutoPlay}
          aria-label={isAutoPlaying ? "Pause" : "Play"}
        >
          {isAutoPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
        </Button>

        <Button
          variant="outline"
          size="icon"
          className="bg-white/10 backdrop-blur-sm border-white text-white hover:bg-white/20 h-12 w-12 rounded-full"
          onClick={nextSlide}
          aria-label="Next slide"
          disabled={isAnimating}
        >
          <ChevronRight className="h-6 w-6" />
        </Button>
      </div>

      {/* Slide indicators */}
      <div className="absolute bottom-24 left-1/2 -translate-x-1/2 flex space-x-2 z-30">
        {backgroundSlides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index, index > currentIndex ? "next" : "prev")}
            className={cn(
              "w-3 h-3 rounded-full transition-all duration-300",
              index === currentIndex ? "bg-white w-8" : "bg-white/50 hover:bg-white/80",
            )}
            aria-label={`Go to slide ${index + 1}`}
            disabled={isAnimating}
          />
        ))}
      </div>

      {/* Expanded View Modal */}
      {showExpanded && currentSlide.expandedContent && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 md:p-8 animate-fade-in">
          <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl animate-scale-in">
            <div className="relative p-6 md:p-8">
              {/* Close button */}
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-4 top-4 text-gray-500 hover:text-gray-800 hover:bg-gray-100"
                onClick={handleCloseExpanded}
                aria-label="Close"
              >
                <X className="h-6 w-6" />
              </Button>

              {/* Content */}
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                {currentSlide.expandedContent.title}
              </h2>

              <p className="text-gray-700 mb-6 text-lg">{currentSlide.expandedContent.description}</p>

              {/* Features */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-800 mb-3">Đặc điểm nổi bật</h3>
                <ul className="space-y-2">
                  {currentSlide.expandedContent.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <div className="mr-2 mt-1 h-2 w-2 rounded-full bg-emerald-500 flex-shrink-0"></div>
                      <span className="text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Image Gallery */}
              <div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Bộ sưu tập hình ảnh</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {currentSlide.expandedContent.imageGallery.map((image, index) => (
                    <div
                      key={index}
                      className="relative h-60 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300"
                    >
                      <Image
                        src={image || "/placeholder.svg"}
                        alt={`Gallery image ${index + 1}`}
                        fill
                        className="object-cover hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Action button */}
              <div className="mt-8 flex justify-center">
                <Button className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-2 rounded-full">
                  Khám phá ngay
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
