import { NatureSlider } from "@/components/nature-slider"

export default function Home() {
  return (
    <main className="min-h-screen">
      <NatureSlider />
    </main>
  )
}
