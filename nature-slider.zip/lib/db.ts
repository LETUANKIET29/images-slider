import { neon } from "@neondatabase/serverless"

// Add more detailed environment variable checking
console.log("Checking DATABASE_URL environment variable...")
const databaseUrl = process.env.DATABASE_URL

if (!databaseUrl) {
  console.error("❌ DATABASE_URL environment variable is not defined")
  throw new Error("DATABASE_URL environment variable is not defined")
}

console.log("✅ DATABASE_URL is defined:", databaseUrl.substring(0, 20) + "...")

// Create Neon SQL client with error handling
let sql: any
try {
  sql = neon(databaseUrl)
  console.log("✅ Neon client created successfully")
} catch (error) {
  console.error("❌ Failed to create Neon client:", error)
  throw new Error(`Failed to create Neon client: ${error instanceof Error ? error.message : "Unknown error"}`)
}

export { sql }

// Test database connection with detailed error handling
export async function testConnection() {
  try {
    console.log("🔄 Testing Neon database connection...")

    if (!sql) {
      throw new Error("SQL client is not initialized")
    }

    const result = await sql`SELECT 1 AS test, NOW() AS current_time, version() AS db_version`

    console.log("✅ Neon connection test successful:", result[0])
    return {
      success: true,
      data: result[0],
      message: "Successfully connected to Neon database",
    }
  } catch (error) {
    console.error("❌ Neon connection test failed:", error)

    // Provide more specific error information
    let errorMessage = "Unknown connection error"
    let errorDetails: any = {}

    if (error instanceof Error) {
      errorMessage = error.message
      errorDetails = {
        name: error.name,
        message: error.message,
        stack: error.stack?.split("\n").slice(0, 5), // First 5 lines of stack
      }
    }

    return {
      success: false,
      error: errorMessage,
      details: errorDetails,
      troubleshooting: {
        checkDatabaseUrl: "Verify DATABASE_URL format: postgres://user:pass@host:port/db",
        checkNetwork: "Ensure network connectivity to Neon",
        checkPermissions: "Verify database user has proper permissions",
      },
    }
  }
}

// Initialize database schema with better error handling
export async function initializeDatabase() {
  try {
    console.log("🔄 Initializing Neon database schema...")

    if (!sql) {
      throw new Error("SQL client is not initialized")
    }

    // Create users table if it doesn't exist (PostgreSQL syntax)
    const result = await sql`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `

    console.log("✅ Neon database initialization successful")
    return {
      success: true,
      message: "Users table created successfully or already exists",
      result: result,
    }
  } catch (error) {
    console.error("❌ Neon database initialization failed:", error)

    let errorMessage = "Unknown initialization error"
    let errorDetails: any = {}

    if (error instanceof Error) {
      errorMessage = error.message
      errorDetails = {
        name: error.name,
        message: error.message,
        stack: error.stack?.split("\n").slice(0, 5),
      }
    }

    return {
      success: false,
      error: errorMessage,
      details: errorDetails,
      troubleshooting: {
        checkSqlSyntax: "Verify PostgreSQL syntax is correct",
        checkPermissions: "Ensure user has CREATE TABLE permissions",
        checkConnection: "Verify database connection is stable",
      },
    }
  }
}

// Rest of the functions remain the same but with improved error handling...
export async function getAllUsers() {
  try {
    console.log("🔄 Getting all users...")
    const result = await sql`SELECT * FROM users ORDER BY created_at DESC`
    console.log(`✅ Retrieved ${result.length} users`)
    return { success: true, data: result }
  } catch (error) {
    console.error("❌ Failed to get users:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to get users",
      details: error,
    }
  }
}

export async function addUser(name: string, email: string) {
  try {
    console.log("🔄 Adding new user:", { name, email })
    const result = await sql`
      INSERT INTO users (name, email) 
      VALUES (${name}, ${email}) 
      RETURNING *
    `
    console.log("✅ User added successfully:", result[0])
    return { success: true, data: result[0] }
  } catch (error) {
    console.error("❌ Failed to add user:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to add user",
      details: error,
    }
  }
}

export async function getUserById(id: number) {
  try {
    console.log("🔄 Getting user by ID:", id)
    const result = await sql`SELECT * FROM users WHERE id = ${id}`

    if (result.length === 0) {
      return { success: false, error: "User not found" }
    }

    console.log("✅ User found:", result[0])
    return { success: true, data: result[0] }
  } catch (error) {
    console.error("❌ Failed to get user by ID:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to get user",
      details: error,
    }
  }
}

export async function updateUser(id: number, name: string, email: string) {
  try {
    console.log("🔄 Updating user:", { id, name, email })
    const result = await sql`
      UPDATE users 
      SET name = ${name}, email = ${email} 
      WHERE id = ${id} 
      RETURNING *
    `

    if (result.length === 0) {
      return { success: false, error: "User not found" }
    }

    console.log("✅ User updated successfully:", result[0])
    return { success: true, data: result[0] }
  } catch (error) {
    console.error("❌ Failed to update user:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to update user",
      details: error,
    }
  }
}

export async function deleteUser(id: number) {
  try {
    console.log("🔄 Deleting user:", id)
    const result = await sql`DELETE FROM users WHERE id = ${id} RETURNING id`

    if (result.length === 0) {
      return { success: false, error: "User not found" }
    }

    console.log("✅ User deleted successfully")
    return { success: true, message: "User deleted successfully" }
  } catch (error) {
    console.error("❌ Failed to delete user:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to delete user",
      details: error,
    }
  }
}

export async function searchUsers(query: string) {
  try {
    console.log("🔄 Searching users with query:", query)
    const result = await sql`
      SELECT * FROM users 
      WHERE name ILIKE ${`%${query}%`} 
         OR email ILIKE ${`%${query}%`}
      ORDER BY created_at DESC
    `
    console.log(`✅ Found ${result.length} users matching query`)
    return { success: true, data: result }
  } catch (error) {
    console.error("❌ Failed to search users:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to search users",
      details: error,
    }
  }
}

export async function getUsersWithPagination(page = 1, limit = 10) {
  try {
    console.log("🔄 Getting paginated users:", { page, limit })
    const offset = (page - 1) * limit

    // Get total count
    const countResult = await sql`SELECT COUNT(*) as total FROM users`
    const total = Number(countResult[0].total)

    // Get paginated results
    const result = await sql`
      SELECT * FROM users 
      ORDER BY created_at DESC 
      LIMIT ${limit} OFFSET ${offset}
    `

    console.log(`✅ Retrieved ${result.length} users (page ${page})`)
    return {
      success: true,
      data: result,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
        hasNext: page * limit < total,
        hasPrev: page > 1,
      },
    }
  } catch (error) {
    console.error("❌ Failed to get paginated users:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to get users",
      details: error,
    }
  }
}
